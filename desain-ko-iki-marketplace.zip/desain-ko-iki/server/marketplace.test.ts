import { describe, expect, it } from "vitest";
import { filterProducts, formatPrice, products } from "../client/src/pages/Home";

describe("marketplace catalog helpers", () => {
  it("filters products by category", () => {
    const result = filterProducts(products, "Branding", "");

    expect(result.length).toBeGreaterThan(0);
    expect(result.every((product) => product.category === "Branding")).toBe(true);
  });

  it("filters products by title, creator, or category query", () => {
    const result = filterProducts(products, "Semua", "notion");

    expect(result).toHaveLength(1);
    expect(result[0]?.title).toContain("Notion");
  });

  it("combines category and query filters", () => {
    expect(filterProducts(products, "Social media", "brand identity")).toHaveLength(0);
    expect(filterProducts(products, "Social media", "Rona")).toHaveLength(1);
  });

  it("formats Indonesian rupiah prices", () => {
    expect(formatPrice(89000)).toBe("Rp89.000");
    expect(formatPrice(1250000)).toBe("Rp1.250.000");
  });
});
