import { useMemo, useState } from "react";
import { startLogin } from "@/const";
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  BriefcaseBusiness,
  Check,
  ChevronDown,
  Gift,
  Heart,
  Home as HomeIcon,
  Instagram,
  Layers3,
  Menu,
  Package,
  Palette,
  Search,
  ShoppingBag,
  Sparkles,
  Star,
  UserRound,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";

type Category = "Semua" | "Template" | "Branding" | "Social media" | "Presentasi" | "Keychain";
export type Product = {
  id: number;
  title: string;
  creator: string;
  category: Exclude<Category, "Semua">;
  price: number;
  rating: number;
  reviews: number;
  image: string;
  tone: string;
  badge?: string;
};

export const products: Product[] = [
  { id: 1, title: "Sajian Raya — Social Media Kit", creator: "Ruang Reka", category: "Social media", price: 89000, rating: 4.9, reviews: 128, image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=900&q=85", tone: "#e9e4ff", badge: "Terlaris" },
  { id: 2, title: "Mellow — Brand Identity", creator: "Studio Sore", category: "Branding", price: 245000, rating: 5, reviews: 64, image: "https://images.unsplash.com/photo-1542744094-3a31f272c490?auto=format&fit=crop&w=900&q=85", tone: "#eeeaff", badge: "Baru" },
  { id: 3, title: "Niskala — Pitch Deck", creator: "Biru Langit", category: "Presentasi", price: 129000, rating: 4.8, reviews: 91, image: "https://images.unsplash.com/photo-1558655146-9f40138edfeb?auto=format&fit=crop&w=900&q=85", tone: "#e2e8ff" },
  { id: 4, title: "Rona — Instagram Templates", creator: "Lini Kecil", category: "Social media", price: 79000, rating: 4.9, reviews: 83, image: "https://images.unsplash.com/photo-1531058020387-3be344556be6?auto=format&fit=crop&w=900&q=85", tone: "#f0e8ff" },
  { id: 5, title: "Karsa — Notion Planner", creator: "Matahari Pagi", category: "Template", price: 59000, rating: 4.7, reviews: 47, image: "https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=900&q=85", tone: "#e8e2ff" },
  { id: 6, title: "Kolektif — Logo Collection", creator: "Titik Temu", category: "Branding", price: 179000, rating: 4.9, reviews: 39, image: "https://images.unsplash.com/photo-1559028012-481c04fa702d?auto=format&fit=crop&w=900&q=85", tone: "#e8eaff" },
  { id: 7, title: "Keychain Nama — Custom Acrylic", creator: "Desain Ko Iki", category: "Keychain", price: 25000, rating: 4.9, reviews: 56, image: "https://images.unsplash.com/photo-1611652022419-a9419f74343d?auto=format&fit=crop&w=900&q=85", tone: "#e9e4ff", badge: "Favorit" },
];

export const formatPrice = (value: number) => `Rp${value.toLocaleString("id-ID")}`;
export function filterProducts(items: Product[], category: Category, query: string) {
  const normalizedQuery = query.trim().toLowerCase();
  return items.filter((product) => {
    const matchesCategory = category === "Semua" || product.category === category;
    const matchesQuery = !normalizedQuery || `${product.title} ${product.creator} ${product.category}`.toLowerCase().includes(normalizedQuery);
    return matchesCategory && matchesQuery;
  });
}

const categories: { label: Category; icon: typeof Palette; color: string }[] = [
  { label: "Template", icon: Layers3, color: "#efeaff" },
  { label: "Branding", icon: Palette, color: "#e8e6ff" },
  { label: "Social media", icon: Instagram, color: "#f0e8ff" },
  { label: "Presentasi", icon: BriefcaseBusiness, color: "#e5ecff" },
  { label: "Keychain", icon: Gift, color: "#ede5ff" },
];

function BrandMark({ compact = false }: { compact?: boolean }) {
  return <div className={`flex items-center gap-2.5 ${compact ? "justify-center" : ""}`}><span className="grid size-10 place-items-center rounded-[12px] bg-[#4933b8] text-white shadow-[0_5px_12px_rgba(73,51,184,.25)]"><Zap size={21} fill="currentColor" strokeWidth={2.5} /></span><span className={compact ? "hidden" : "leading-none"}><b className="block text-[18px] font-extrabold tracking-[-.05em] text-[#402899]">DESAINKOIKI</b><small className="mt-1 block text-[9px] font-medium text-[#827aa4]">Desain Jos. Mesti Marem.</small></span></div>;
}

function ProductCard({ product, liked, onLike, onAdd }: { product: Product; liked: boolean; onLike: () => void; onAdd: () => void }) {
  return <article className="group min-w-0 rounded-[18px] border border-[#e9e6f2] bg-white p-2.5 shadow-[0_4px_15px_rgba(67,48,135,.045)] transition duration-200 hover:-translate-y-1 hover:shadow-[0_10px_24px_rgba(67,48,135,.12)]">
    <div className="relative aspect-[1/1.03] overflow-hidden rounded-[13px]" style={{ backgroundColor: product.tone }}>
      <img src={product.image} alt={product.title} className="size-full object-cover transition duration-500 group-hover:scale-105" loading="lazy" />
      <button onClick={onLike} aria-label="Favorit" className={`absolute right-2 top-2 grid size-7 place-items-center rounded-full border border-white/70 backdrop-blur-sm transition active:scale-95 ${liked ? "bg-[#4933b8] text-white" : "bg-white/85 text-[#4933b8]"}`}><Heart size={14} fill={liked ? "currentColor" : "none"} strokeWidth={2} /></button>
      {product.badge && <span className="absolute left-2 top-2 rounded-md bg-white/90 px-2 py-1 text-[9px] font-bold text-[#4933b8]">{product.badge}</span>}
      <span className="absolute bottom-2 left-2 rounded-md bg-[#4933b8] px-2 py-1 font-mono text-[11px] font-medium text-white shadow-md">{formatPrice(product.price)}</span>
    </div>
    <div className="px-0.5 pb-1 pt-3"><h3 className="line-clamp-1 text-[13px] font-bold text-[#2e2850]">{product.title}</h3><div className="mt-1.5 flex items-center justify-between gap-2 text-[10px] text-[#8a84a0]"><span className="line-clamp-1">{product.creator}</span><span className="flex shrink-0 items-center gap-0.5 font-medium text-[#615a7b]"><Star size={11} className="fill-[#ffb338] text-[#ffb338]" /> {product.rating} ({product.reviews})</span></div><button onClick={onAdd} className="mt-2.5 flex w-full items-center justify-center gap-1.5 rounded-lg bg-[#f1effc] py-2 text-[10px] font-bold text-[#4933b8] transition hover:bg-[#4933b8] hover:text-white active:scale-[.98]"><ShoppingBag size={12} /> Tambah</button></div>
  </article>;
}

export default function Home() {
  const [activeCategory, setActiveCategory] = useState<Category>("Semua");
  const [query, setQuery] = useState("");
  const [likedIds, setLikedIds] = useState<number[]>([]);
  const [cartCount, setCartCount] = useState(0);
  const [cartOpen, setCartOpen] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const filteredProducts = useMemo(() => filterProducts(products, activeCategory, query), [activeCategory, query]);
  const chooseCategory = (category: Category) => { setActiveCategory(category); document.getElementById("koleksi")?.scrollIntoView({ behavior: "smooth", block: "start" }); };
  const addToCart = (title: string) => { setCartCount((value) => value + 1); toast.success(`${title} masuk keranjang`, { duration: 1800 }); };

  return <div className="min-h-screen bg-[#fbfbfd] pb-20 text-[#2e2850] lg:pb-0">
    <header className="sticky top-0 z-30 border-b border-[#ebe8f3] bg-white/95 backdrop-blur-md"><div className="mx-auto flex h-[68px] max-w-[1180px] items-center justify-between px-5 lg:px-8"><BrandMark /><nav className="hidden items-center gap-8 text-[13px] font-semibold text-[#77708f] md:flex"><a href="#koleksi" className="hover:text-[#4933b8]">Jelajahi</a><a href="#kategori" className="hover:text-[#4933b8]">Kategori</a><a href="#layanan" className="hover:text-[#4933b8]">Layanan</a></nav><div className="flex items-center gap-2"><button className="hidden size-9 place-items-center rounded-full text-[#6f688a] hover:bg-[#f1effc] sm:grid" onClick={() => document.getElementById("search")?.focus()}><Search size={18} /></button><button onClick={() => startLogin()} className="hidden rounded-full border border-[#ddd9ed] px-4 py-2 text-xs font-bold text-[#4933b8] hover:bg-[#f1effc] sm:block">Masuk</button><button onClick={() => setCartOpen(true)} className="relative grid size-10 place-items-center rounded-full bg-[#4933b8] text-white shadow-[0_5px_12px_rgba(73,51,184,.25)]"><ShoppingBag size={17} />{cartCount > 0 && <span className="absolute -right-1 -top-1 grid size-5 place-items-center rounded-full border-2 border-white bg-[#f04e70] font-mono text-[9px]">{cartCount}</span>}</button><button onClick={() => setMobileMenu((value) => !value)} className="grid size-9 place-items-center rounded-full text-[#4933b8] md:hidden">{mobileMenu ? <X size={19} /> : <Menu size={19} />}</button></div></div>{mobileMenu && <div className="border-t border-[#ebe8f3] bg-white px-5 pb-4 pt-2 md:hidden"><div className="flex flex-col gap-1 text-sm font-semibold text-[#706989]"><a href="#koleksi" className="rounded-xl px-3 py-3 hover:bg-[#f1effc]">Jelajahi produk</a><a href="#kategori" className="rounded-xl px-3 py-3 hover:bg-[#f1effc]">Kategori</a><a href="#layanan" className="rounded-xl px-3 py-3 hover:bg-[#f1effc]">Jasa desain</a></div></div>}</header>

    <main className="mx-auto max-w-[1180px] px-5 lg:px-8">
      <section className="grid gap-7 pb-8 pt-8 lg:grid-cols-[1fr_1.4fr] lg:items-center lg:pt-12"><div><div className="mb-3 flex items-center gap-2 text-xs font-semibold text-[#4933b8]"><span className="grid size-6 place-items-center rounded-full bg-[#eeeaff]"><Sparkles size={13} /></span> Welcome back, kreator!</div><h1 className="max-w-[460px] text-[34px] font-extrabold leading-[1.08] tracking-[-.055em] text-[#2e2850] sm:text-[45px]">Cari desain yang <span className="text-[#4933b8]">bikin kamu puas.</span></h1><p className="mt-3 max-w-[420px] text-sm leading-6 text-[#85809a]">Logo, undangan, konten sosial media, sampai keychain custom—semua kebutuhan visual dalam satu tempat.</p></div><div id="search" className="relative overflow-hidden rounded-[24px] bg-gradient-to-br from-[#684fe4] via-[#4933b8] to-[#28146f] p-6 text-white shadow-[0_15px_35px_rgba(73,51,184,.2)]"><div className="absolute -right-10 -top-12 size-40 rounded-full border-[18px] border-white/10" /><div className="absolute -bottom-24 right-20 size-48 rounded-full border-[20px] border-white/10" /><div className="relative max-w-[440px]"><span className="rounded-full bg-white/15 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.14em]">Promo minggu ini</span><h2 className="mt-4 text-2xl font-extrabold leading-tight sm:text-3xl">Diskon 30% untuk<br /><span className="text-[#dcd6ff]">desain pertama kamu!</span></h2><p className="mt-2 text-xs text-white/75">Limited time offer. Shop now!</p><button onClick={() => document.getElementById("koleksi")?.scrollIntoView({ behavior: "smooth" })} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-3 text-xs font-bold text-[#4933b8] shadow-lg hover:bg-[#f1effc]">Belanja sekarang <ArrowRight size={14} /></button></div><div className="absolute bottom-0 right-5 hidden h-36 w-36 overflow-hidden rounded-t-[28px] border-4 border-white/30 sm:block"><img src={products[6].image} alt="Keychain custom" className="size-full object-cover" /></div></div></section>

      <section id="kategori" className="py-5"><div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-extrabold text-[#2e2850]">Kategori</h2><button onClick={() => chooseCategory("Semua")} className="text-xs font-bold text-[#4933b8]">Lihat semua</button></div><div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">{categories.map(({ label, icon: Icon, color }) => <button key={label} onClick={() => chooseCategory(label)} className="group flex min-w-[82px] flex-col items-center gap-2"><span className={`grid size-14 place-items-center rounded-[18px] border transition ${activeCategory === label ? "border-[#4933b8] bg-[#4933b8] text-white shadow-[0_7px_14px_rgba(73,51,184,.2)]" : "border-[#e9e6f2] text-[#4933b8] group-hover:border-[#4933b8]"}`} style={activeCategory === label ? undefined : { backgroundColor: color }}><Icon size={21} strokeWidth={1.8} /></span><span className="whitespace-nowrap text-[10px] font-semibold text-[#716b8c]">{label}</span></button>)}</div></section>

      <section id="layanan" className="rounded-[20px] border border-[#e9e6f2] bg-white p-5 shadow-[0_4px_15px_rgba(67,48,135,.04)]"><div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-extrabold text-[#2e2850]">Jasa Desain</h2><span className="rounded-full bg-[#f1effc] px-2.5 py-1 text-[10px] font-bold text-[#4933b8]">Custom tersedia</span></div><div className="grid grid-cols-2 gap-x-5 gap-y-3 text-xs font-semibold text-[#5f5879] sm:grid-cols-3 lg:grid-cols-6"><span className="flex items-center gap-2"><Check size={14} className="text-[#4933b8]" /> Logo</span><span className="flex items-center gap-2"><Check size={14} className="text-[#4933b8]" /> Undangan</span><span className="flex items-center gap-2"><Check size={14} className="text-[#4933b8]" /> Konten Sosial</span><span className="flex items-center gap-2"><Check size={14} className="text-[#4933b8]" /> Poster</span><span className="flex items-center gap-2"><Check size={14} className="text-[#4933b8]" /> Kemasan</span><span className="flex items-center gap-2"><Check size={14} className="text-[#4933b8]" /> MMT / Stiker</span></div></section>

      <section id="koleksi" className="scroll-mt-24 py-10"><div className="mb-5 flex items-end justify-between"><div><h2 className="text-xl font-extrabold text-[#2e2850]">Produk pilihan</h2><p className="mt-1 text-xs text-[#8a84a0]">Yang sedang banyak disukai</p></div><button onClick={() => { setActiveCategory("Semua"); setQuery(""); }} className="flex items-center gap-1 text-xs font-bold text-[#4933b8]">Lihat semua <ArrowRight size={13} /></button></div><div className="mb-5 flex gap-2 overflow-x-auto pb-1">{(["Semua", "Template", "Branding", "Social media", "Presentasi", "Keychain"] as Category[]).map((category) => <button key={category} onClick={() => setActiveCategory(category)} className={`whitespace-nowrap rounded-full border px-3.5 py-2 text-[11px] font-semibold transition ${activeCategory === category ? "border-[#4933b8] bg-[#4933b8] text-white" : "border-[#e4e0ef] bg-white text-[#77708f] hover:border-[#4933b8] hover:text-[#4933b8]"}`}>{category}</button>)}</div>{filteredProducts.length ? <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 lg:gap-5">{filteredProducts.map((product) => <ProductCard key={product.id} product={product} liked={likedIds.includes(product.id)} onLike={() => setLikedIds((current) => current.includes(product.id) ? current.filter((id) => id !== product.id) : [...current, product.id])} onAdd={() => addToCart(product.title)} />)}</div> : <div className="rounded-2xl border border-dashed border-[#d6d0ed] p-12 text-center text-sm text-[#827aa4]">Produk tidak ditemukan.</div>}</section>
    </main>

    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-[#e9e6f2] bg-white/95 px-4 py-2.5 backdrop-blur-md lg:hidden"><div className="mx-auto flex max-w-md items-center justify-around"><button className="flex flex-col items-center gap-1 text-[#4933b8]"><HomeIcon size={19} fill="currentColor" /><span className="text-[9px] font-bold">Home</span></button><button onClick={() => document.getElementById("koleksi")?.scrollIntoView({ behavior: "smooth" })} className="flex flex-col items-center gap-1 text-[#a7a1b8]"><Package size={19} /><span className="text-[9px] font-semibold">Produk</span></button><button onClick={() => setLikedIds(products.map((product) => product.id))} className="flex flex-col items-center gap-1 text-[#a7a1b8]"><Heart size={19} /><span className="text-[9px] font-semibold">Favorit</span></button><button onClick={() => startLogin()} className="flex flex-col items-center gap-1 text-[#a7a1b8]"><UserRound size={19} /><span className="text-[9px] font-semibold">Profil</span></button></div></nav>

    <footer className="hidden border-t border-[#ebe8f3] bg-white lg:block"><div className="mx-auto flex max-w-[1180px] items-center justify-between px-8 py-8"><BrandMark /><p className="text-xs text-[#8a84a0]">Desain Jos. Mesti Marem. © 2026 DESAINKOIKI</p><div className="flex gap-3 text-[#827aa4]"><Instagram size={16} /><Bell size={16} /></div></div></footer>

    {cartOpen && <div className="fixed inset-0 z-50"><button className="absolute inset-0 bg-[#2e2850]/35 backdrop-blur-sm" onClick={() => setCartOpen(false)} aria-label="Tutup" /><aside className="absolute bottom-0 right-0 top-0 flex w-full max-w-[380px] flex-col bg-white p-5 shadow-2xl"><div className="flex items-center justify-between border-b border-[#ebe8f3] pb-4"><div><p className="text-[10px] font-bold uppercase tracking-[.16em] text-[#4933b8]">Keranjang</p><h2 className="mt-1 text-2xl font-extrabold text-[#2e2850]">Pesanan kamu</h2></div><button onClick={() => setCartOpen(false)} className="grid size-9 place-items-center rounded-full bg-[#f1effc] text-[#4933b8]"><X size={17} /></button></div><div className="flex flex-1 flex-col items-center justify-center text-center">{cartCount ? <><span className="grid size-16 place-items-center rounded-full bg-[#e9e4ff] text-[#4933b8]"><Check /></span><h3 className="mt-4 text-xl font-extrabold">{cartCount} produk siap dipesan</h3><p className="mt-2 text-sm text-[#827aa4]">Checkout demo akan tersedia saat payment gateway terhubung.</p><button className="mt-5 rounded-xl bg-[#4933b8] px-5 py-3 text-xs font-bold text-white" onClick={() => toast.info("Checkout segera tersedia.")}>Lanjut checkout</button></> : <><span className="grid size-16 place-items-center rounded-full bg-[#f1effc] text-[#4933b8]"><ShoppingBag /></span><h3 className="mt-4 text-xl font-extrabold">Keranjang masih kosong</h3><p className="mt-2 text-sm text-[#827aa4]">Tambahkan produk favoritmu untuk mulai berbelanja.</p></>}</div></aside></div>}
  </div>;
}
